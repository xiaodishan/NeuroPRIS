import argparse
import datetime
import json
import numpy as np
import tensorflow as tf
from keras import layers
from tensorflow import keras
from sklearn.metrics import roc_curve, auc
from Bio import PDB
import glob
import os
import random
from typing import List, Dict
import pandas as pd
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed
from abc import ABC


# Define a constant for both max length and sequence length
SEQ_MAX_LENGTH = 150

# Set random seed
tf.random.set_seed(1234)
random.seed(1234)

# === Data Generation Code ===

def get_padding_sequence_indices(sequences: List[str], seq_map: Dict[str, int], max_length: int = SEQ_MAX_LENGTH) -> np.ndarray:
    indices = [list(map(lambda x: seq_map.get(x), list(seq))) for seq in sequences]
    padding_seqs = keras.utils.pad_sequences(indices, value=0, padding='post', maxlen=max_length)
    return padding_seqs

def get_coords_for_seq_from_single_pdb(sequence, pdb_path, num_points=1426):
    try:
        parser = PDB.PDBParser(QUIET=True)
        structure = parser.get_structure(pdb_path.split('/')[-1].split('.')[0], pdb_path)
        model = structure[0]
        whole_sequence = ''.join(map(lambda a: a.get_resname(), list(model.get_residues())))
        start_index = whole_sequence.index(sequence)
        end_index = start_index + len(sequence)
        residues = list(model.get_residues())[start_index:end_index]
        coords = []
        for residue in residues:
            for atom in residue:
                if 'C' in atom.get_id() or 'c' in atom.get_id():
                    coords.append(atom.get_coord())
        coords_df = pd.DataFrame(coords)
        coords_np_res = np.array(coords_df.sample(n=num_points, replace=True), dtype=np.float32)
    except Exception as e:
        return None, sequence

    return {sequence: coords_np_res}, None

def parallel_get_coords_for_seq(sequences, pdb_paths_list, num_points=1426, max_workers=60):
    seq_coords_np_res_map = {}
    error_sequences = []
    with ThreadPoolExecutor(max_workers) as executor:
        futures = {executor.submit(get_coords_for_seq_from_single_pdb, s, p): p for s, p in zip(sequences, pdb_paths_list)}
        for future in tqdm(as_completed(futures), total=len(futures)):
            coords_np_res, error_sequence = future.result()
            if coords_np_res:
                seq_coords_np_res_map.update(coords_np_res)
            if error_sequence:
                error_sequences.append(error_sequence)
    return error_sequences, seq_coords_np_res_map

def get_pdb_path_base_on_rna_name(rna_name, pdb_folder):
    pdb_paths = glob.glob(f'{pdb_folder}/{rna_name}.pred.pdb')
    return pdb_paths, bool(pdb_paths)

def get_seq_and_sec_shape_and_3d_coords_list(paths, pdb_folder):
    seq_info_map = {}
    sequences = []
    pdb_paths_list = []
    for path in paths:
        with open(path, 'r') as f:
            line = f.readline().strip()
            while line:
                if line.startswith('ENST'):
                    seq_id = line
                    rna_name = line.split('_')[0]
                    sequence = f.readline().strip()
                    secshape_str = f.readline().strip()
                    pdb_paths, flag = get_pdb_path_base_on_rna_name(rna_name, pdb_folder)
                    if not flag:
                        line = f.readline().strip()
                        continue
                    pdb_paths_list.append(pdb_paths[0])
                    sequences.append(sequence)
                    seq_info_map[sequence] = [seq_id, secshape_str]

                line = f.readline().strip()

    error_sequences, seq_coords_np_res_map = parallel_get_coords_for_seq(sequences, pdb_paths_list)

    final_sequences = list(seq_coords_np_res_map.keys())
    coords_3d_list = list(seq_coords_np_res_map.values())
    final_seq_ids = [seq_info_map[seq][0] for seq in final_sequences]
    secshapes = [seq_info_map[seq][1] for seq in final_sequences]

    return final_sequences, secshapes, coords_3d_list, final_seq_ids

def generate_dataset(negative_data_path, output_dataset_path, pdb_folder):
    RNA_map = {'A': 1, 'C': 2, 'G': 3, 'U': 4}
    secshape_map = {'.': 1, '(': 2, ')': 2}

    positive_data_path = negative_data_path.replace('negative', 'positive')

    pos_sequences, pos_secshapes, pos_3d_coords, pos_seq_ids = get_seq_and_sec_shape_and_3d_coords_list([positive_data_path], pdb_folder)
    neg_sequences, neg_secshapes, neg_3d_coords, neg_seq_ids = get_seq_and_sec_shape_and_3d_coords_list([negative_data_path], pdb_folder)

    pos_sequences = get_padding_sequence_indices(pos_sequences, RNA_map).tolist()
    pos_secshapes = get_padding_sequence_indices(pos_secshapes, secshape_map).tolist()
    neg_sequences = get_padding_sequence_indices(neg_sequences, RNA_map).tolist()
    neg_secshapes = get_padding_sequence_indices(neg_secshapes, secshape_map).tolist()

    pos_labels = [1] * len(pos_sequences)
    neg_labels = [0] * len(neg_sequences)

    sequences_inputs = pos_sequences + neg_sequences
    secshape_inputs = pos_secshapes + neg_secshapes
    coords_3d_inputs = pos_3d_coords + neg_3d_coords
    labels = pos_labels + neg_labels
    seq_ids = pos_seq_ids + neg_seq_ids

    all_dataset = tf.data.Dataset.from_tensor_slices(({"sequences_inputs": sequences_inputs,
                                                       "secshape_inputs": secshape_inputs,
                                                       "coords_3d_inputs": coords_3d_inputs},
                                                       {"outputs": labels}, {"seq_ids": seq_ids}))

    all_dataset = all_dataset.shuffle(len(labels)).shuffle(2048)

    train_count = int(len(all_dataset) * 0.8)
    val_count = int(len(all_dataset) * 0.1)

    train_dataset = all_dataset.take(train_count)
    val_dataset = all_dataset.skip(train_count).take(val_count)
    test_dataset = all_dataset.skip(train_count + val_count)

    train_dataset.save(f'{output_dataset_path}/train_dataset')
    val_dataset.save(f'{output_dataset_path}/val_dataset')
    test_dataset.save(f'{output_dataset_path}/test_dataset')

    predict_dataset = tf.data.Dataset.from_tensor_slices(({"sequences_inputs": sequences_inputs,
                                                           "secshape_inputs": secshape_inputs,
                                                           "coords_3d_inputs": coords_3d_inputs},
                                                           {"outputs": labels}, {"seq_ids": seq_ids}))
    predict_dataset.save(f'{output_dataset_path}/predict_dataset')

    return output_dataset_path

# === Model Training Code ===

class CustomSchedule(keras.optimizers.schedules.LearningRateSchedule, ABC):
    def __init__(self, d_model, warmup_steps=50, **kwargs):
        super(CustomSchedule, self).__init__(**kwargs)
        self.d_model = d_model
        self.d_model = tf.cast(self.d_model, tf.float32)
        self.warmup_steps = warmup_steps

    def __call__(self, step):
        step = tf.cast(step, dtype=tf.float32)
        arg1 = tf.math.rsqrt(step)
        arg2 = step * (self.warmup_steps ** -1.5)
        return tf.math.rsqrt(self.d_model) * tf.math.minimum(arg1, arg2)

class OrthogonalRegularizer(keras.layers.Layer):
    def __init__(self, num_features, l2reg=0.001, **kwargs):
        super(OrthogonalRegularizer, self).__init__(**kwargs)
        self.num_features = num_features
        self.l2reg = l2reg
        self.eye = tf.eye(num_features)

    def get_config(self):
        config = super(OrthogonalRegularizer, self).get_config().copy()
        config.update({
            "num_features": self.num_features,
            "l2reg": self.l2reg,
        })
        return config

    def __call__(self, x):
        x = tf.reshape(x, (-1, self.num_features, self.num_features))
        xxt = tf.tensordot(x, x, axes=(2, 2))
        xxt = tf.reshape(xxt, (-1, self.num_features, self.num_features))
        return tf.reduce_sum(self.l2reg * tf.square(xxt - self.eye))

class Conv_bn(keras.layers.Layer):
    def __init__(self, filters, **kwargs):
        super(Conv_bn, self).__init__(**kwargs)
        self.filters = filters
        self.conv_1d = layers.Conv1D(filters, kernel_size=1, padding='valid')
        self.conv_1d.supports_masking = True
        self.batch_normalization = layers.BatchNormalization(momentum=0.0)
        self.activation = layers.Activation('relu')
        self.supports_masking = True

    def get_config(self):
        config = super(Conv_bn, self).get_config().copy()
        config.update({
            "filters": self.filters
        })
        return config

    def __call__(self, inputs):
        x = self.conv_1d(inputs)
        x = self.batch_normalization(x)
        outputs = self.activation(x)
        return outputs

class Dense_bn(keras.layers.Layer):
    def __init__(self, filters, **kwargs):
        super(Dense_bn, self).__init__(**kwargs)
        self.filters = filters
        self.dense = layers.Dense(filters)
        self.batch_normalization = layers.BatchNormalization(momentum=0.0)
        self.activation = layers.Activation('relu')
        self.supports_masking = True

    def get_config(self):
        config = super(Dense_bn, self).get_config().copy()
        config.update({
            'filters': self.filters
        })
        return config

    def __call__(self, inputs):
        x = self.dense(inputs)
        x = self.batch_normalization(x)
        outputs = self.activation(x)
        return outputs

class Dense_Layer(keras.layers.Layer):
    def __init__(self, filters, dff, **kwargs):
        super(Dense_Layer, self).__init__(**kwargs)
        self.filters = filters
        self.dense = layers.Dense(dff, activation='relu')
        self.dense2 = layers.Dense(filters)
        self.layer_normalization = layers.LayerNormalization(epsilon=1e-6)
        self.dropout = layers.Dropout(0.1)
        self.supports_masking = True

    def get_config(self):
        config = super(Dense_Layer, self).get_config().copy()
        config.update({
            'filters': self.filters
        })
        return config

    def __call__(self, inputs):
        x = self.dense(inputs)
        x = self.dense2(x)
        x = self.dropout(x)

        inputs_projection = layers.Dense(self.filters)(inputs)

        outputs = self.layer_normalization(inputs_projection + x)
        return outputs

class Tnet(keras.layers.Layer):
    def __init__(self, num_features, **kwargs):
        super(Tnet, self).__init__(**kwargs)
        self.num_features = num_features
        self.bias = keras.initializers.Constant(np.eye(num_features).flatten())
        self.reg = OrthogonalRegularizer(num_features)
        self.conv_bn_1 = Conv_bn(32)
        self.conv_bn_2 = Conv_bn(64)
        self.conv_bn_3 = Conv_bn(512)
        self.max_pooling = layers.GlobalMaxPooling1D()
        self.dense_bn_1 = Dense_bn(256)
        self.dense_bn_2 = Dense_bn(128)
        self.dense = layers.Dense(num_features * num_features,
                                  kernel_initializer="zeros",
                                  bias_initializer=self.bias,
                                  activity_regularizer=self.reg)
        self.reshape = layers.Reshape((num_features, num_features))
        self.dot = layers.Dot(axes=(2, 1))

    def get_config(self):
        config = super(Tnet, self).get_config().copy()
        config.update({
            'num_features': self.num_features
        })
        return config

    def __call__(self, inputs):
        x = self.conv_bn_1(inputs)
        x = self.conv_bn_2(x)
        x = self.conv_bn_3(x)
        x = self.max_pooling(x)
        x = self.dense_bn_1(x)
        x = self.dense_bn_2(x)
        x = self.dense(x)
        feat_T = self.reshape(x)
        outputs = self.dot([inputs, feat_T])
        return outputs

class NeuroPRIS:
    def __init__(self, num_points=1426, EPOCHS=20, dataname='', learning_rate=None, lstm_units=48):
        self.NUM_POINTS = num_points
        self.NUM_CLASSES = 2
        self.EPOCHS = EPOCHS
        self.myModel = None
        self.seq_length = SEQ_MAX_LENGTH
        self.modelname = f'{dataname}'
        self.learning_rate = learning_rate or 0.001
        self.lstm_units = lstm_units

    def model_build(self, return_seq=False):
        sequences_inputs = keras.Input(shape=self.seq_length, name='sequences_inputs')
        secshape_inputs = keras.Input(shape=self.seq_length, name='secshape_inputs')
        coords_3d_inputs = keras.Input(shape=(self.NUM_POINTS, 3), name='coords_3d_inputs')

        x1 = Tnet(3)(coords_3d_inputs)
        x1 = Conv_bn(32)(x1)
        x1 = Conv_bn(32)(x1)
        x1 = Tnet(32)(x1)
        x1 = Conv_bn(32)(x1)
        x1 = Conv_bn(64)(x1)
        x1 = Conv_bn(128)(x1)
        x1 = layers.GlobalMaxPooling1D()(x1)
        x1 = layers.Reshape((128, 1))(x1)

        x1 = layers.Masking()(x1)

        x2 = layers.Embedding(input_dim=5, output_dim=127, mask_zero=True, name='embedding_sequence_layer')(sequences_inputs)
        x3 = layers.Embedding(input_dim=3, output_dim=128, mask_zero=True, name='embedding_secshape_layer')(secshape_inputs)

        x = layers.Dot(axes=(2, 1))([x3, x1])
        x = layers.Concatenate(axis=-1)([x2, x])

        x = layers.Bidirectional(layers.LSTM(units=self.lstm_units, return_sequences=return_seq),
                                 merge_mode='sum', name='biLstm')(x)

        x = Dense_Layer(48, 64)(x)

        outputs = layers.Dense(self.NUM_CLASSES, activation="softmax", name='outputs')(x)

        model = keras.Model(inputs=[sequences_inputs, secshape_inputs, coords_3d_inputs], outputs=outputs, name=self.modelname)

        model.compile(loss=tf.keras.losses.sparse_categorical_crossentropy,
                      optimizer=keras.optimizers.Adam(learning_rate=self.learning_rate, beta_1=0.9, beta_2=0.98, epsilon=1e-9),
                      metrics=[tf.keras.metrics.sparse_categorical_accuracy])

        self.myModel = model

    def model_fit(self, train_dataset, val_dataset):
        early_stopping = tf.keras.callbacks.EarlyStopping(
            monitor='val_loss',
            patience=50,
            verbose=1,
            restore_best_weights=True
        )

        self.myModel.fit(train_dataset, epochs=self.EPOCHS, validation_data=val_dataset,
                         callbacks=[early_stopping])

    def model_save(self, saveprefix='./model'):
        filename = f'{saveprefix}/{self.modelname}/{self.modelname}'
        self.myModel.save_weights(filename)
        self.myModel.save(f'{filename}.model')

    def load(self, model_path):
        self.myModel.load_weights(model_path)

    def model_summary(self):
        self.myModel.summary()

    def predict(self, x):
        y_pre = self.myModel.predict(x)
        return y_pre

    def evaluate(self, dataset):
        loss, acc = self.myModel.evaluate(dataset)
        return loss, acc

def train_model(output_dataset_path, data_name, save_prefix, EPOCHS, base_lr, lstm_units):
    num_points = 1426
    BATCH_SIZE = 64

    model = NeuroPRIS(num_points=num_points, EPOCHS=EPOCHS, dataname=data_name,
                      learning_rate=base_lr, lstm_units=lstm_units)
    model.model_build()
    model.model_summary()

    train_dataset = tf.data.Dataset.load(f"{output_dataset_path}/train_dataset")
    val_dataset = tf.data.Dataset.load(f"{output_dataset_path}/val_dataset")

    def preprocess_sample(inputs, outputs, seq_ids):
        return inputs, outputs

    train_dataset = train_dataset.map(preprocess_sample)
    val_dataset = val_dataset.map(preprocess_sample)

    train_dataset = train_dataset.shuffle(800).batch(batch_size=BATCH_SIZE)
    val_dataset = val_dataset.shuffle(800).batch(batch_size=BATCH_SIZE)

    model.model_fit(train_dataset, val_dataset)

    loss, acc = model.evaluate(val_dataset)
    print(f'Evaluated Loss: {loss}, Evaluated Accuracy: {acc}')

    # Save the model
    model.model_save(saveprefix=save_prefix)

    # Return the save path
    model_path = os.path.join(save_prefix, f"{data_name}.model")  # Assuming `.model` is your format
    return model_path

# === Prediction Code ===

def get_roc_result(data_names, save_prefix, data_name, test_data_path, output_path, num_points):
    if len(data_names) == 0:
        print("Error: Data names cannot be empty.")
        return

    primary_name = data_names[-1]

    # Initialize the model
    model = NeuroPRIS(num_points=num_points)
    model.model_build()

    # Locate the index file
    model_index_path = glob.glob(f"{save_prefix}/{data_name}/*.index")
    if not model_index_path:
        print(f"No model index file found in path {save_prefix}/{data_name}*/")
        return

    # Build the full path by removing the `.index` extension
    model_weights_path = model_index_path[0].replace('.index', '')

    # Load model weights
    model.load(model_weights_path)
    model.model_summary()

    # Load and preprocess the test dataset
    test_dataset = tf.data.Dataset.load(test_data_path)
    y_trues = list(map(lambda a: int(a[1]['outputs']), test_dataset))
    test_dataset = test_dataset.batch(64)

    # Make predictions
    y_preds = model.predict(test_dataset)
    y_preds = [pred[-1] for pred in y_preds]

    # Log some outputs
    print(f'y_trues: {y_trues[:5]}')
    print(f'y_preds: {y_preds[:5]}')

    y_unique = {}
    for k in y_trues:
        y_unique[k] = y_unique.get(k, 0) + 1
    print(f'y_unique: {y_unique}')

    # Compute ROC curve and AUC
    fpr, tpr, _ = roc_curve(y_trues, y_preds)
    auroc = auc(fpr, tpr)
    print(f'AUROC: {auroc}')

    # Prepare the result data
    result = {
        'auroc': auroc,
        'data': list(zip(fpr, tpr))
    }

    # Save the results as a JSON file
    json_result = json.dumps(result, indent=4)
    used_model = os.path.basename(model_weights_path)
    json_output_path = os.path.join(output_path, f'{used_model}_{primary_name}.json')
    with open(json_output_path, 'w') as fw:
        fw.write(json_result)

    return json_output_path


num_points = 1426

# === Combine and Control Main Process ===

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Automate data generation, model training, and prediction sequence.')
    parser.add_argument('--negative_data_path', type=str, required=True, help='Path to the negative data file.')
    parser.add_argument('--output_dataset_path', type=str, required=True, help='Path where datasets will be saved.')
    parser.add_argument('--pdb_folder', type=str, required=True, help='Path to the PDB folder.')
    parser.add_argument('--data_name', type=str, required=True, help='Name of the dataset to be created and used.')
    parser.add_argument('--save_prefix', type=str, default='./model', help='Prefix for model save directories.')
    parser.add_argument('--EPOCHS', type=int, default=10, help='Number of training epochs.')
    parser.add_argument('--base_lr', type=float, default=0.001, help='Base learning rate for training.')
    parser.add_argument('--lstm_units', type=int, default=48, help='Number of LSTM units.')
    parser.add_argument('--output_path', type=str, required=True, help='Path for storing prediction outputs.')
    parser.add_argument('--num_points', type=int, default=num_points, help='Number of points for 3D coordinates.')
    args = parser.parse_args()

    # Step 1: Data Generation
    dataset_path = generate_dataset(args.negative_data_path, args.output_dataset_path, args.pdb_folder)
    print('Dataset generated at:', dataset_path)

    # Step 2: Model Training
    model_path = train_model(dataset_path, args.data_name, args.save_prefix, args.EPOCHS, args.base_lr, args.lstm_units)

    # Step 3: Use Trained Model for Prediction
    test_data_path = f"{dataset_path}/test_dataset"
    get_roc_result([args.data_name], args.save_prefix, args.data_name, test_data_path, args.output_path, args.num_points)